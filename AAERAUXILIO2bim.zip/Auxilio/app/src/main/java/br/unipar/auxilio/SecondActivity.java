package br.unipar.auxilio;

class SecondActivity {
}
